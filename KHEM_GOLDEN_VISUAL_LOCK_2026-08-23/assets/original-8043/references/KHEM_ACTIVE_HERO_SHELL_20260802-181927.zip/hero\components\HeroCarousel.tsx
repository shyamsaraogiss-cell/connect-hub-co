'use client';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { heroSlides } from '../data/homepageHeroSlides';
import { CoreServicesBand } from './CoreServicesBand';
import { HeroAssistantPanel } from './HeroAssistantPanel';
import { HeroArrows, HeroDots } from './HeroNavigation';
import { HeroSlide } from './HeroSlide';
import styles from '../HeroCarousel.module.css';
// =======================================
// SITARAM HERO MASTER v1.1
// PERMANENTLY LOCKED
// DO NOT MODIFY WITHOUT EXPLICIT APPROVAL
// ROTATING PACKAGE
// =======================================
// SITARAM_HERO_2_RITUAL_SERVICES_v1.1_FINAL_LOCK
// DO NOT MODIFY WITHOUT EXPLICIT USER APPROVAL
const getHeroIndex = (heroId: string | null) => {
  const index = heroSlides.findIndex((slide) => slide.id === heroId);
  return index >= 0 ? index : 0;
};
type HeroCarouselProps =
  | { carouselMode?: 'home'; fixedSlideId?: never }
  | { carouselMode: 'static'; fixedSlideId: string };

export function HeroCarousel({ carouselMode = 'home', fixedSlideId }: HeroCarouselProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const staticMode = carouselMode === 'static';
  const fixedSlide = staticMode
    ? heroSlides.find((candidate) => candidate.id === fixedSlideId)
    : undefined;
  const activeSlides = fixedSlide ? [fixedSlide] : heroSlides;
  const activeHeroIndex = fixedSlide ? 0 : getHeroIndex(searchParams.get('hero'));
  const total = activeSlides.length;
  const slide = activeSlides[activeHeroIndex];
  const ritual = slide.id === 'ritual-services';
  const heroOne = slide.id === 'pitru-moksha-gaya';
  const travel = slide.id === 'travel-assistance';
  const move = (direction: -1 | 1) => {
    if (total <= 1) return;
    const next = (activeHeroIndex + direction + total) % total;
    const params = new URLSearchParams(searchParams.toString());
    params.set('hero', activeSlides[next].id);
    router.replace(`${pathname}?${params.toString()}`, { scroll: false });
  };
  const onKeyDown = (event: React.KeyboardEvent<HTMLElement>) => {
    if (staticMode) return;
    if (event.key === 'ArrowLeft') move(-1);
    if (event.key === 'ArrowRight') move(1);
  };
  return (
    <section
      className={`${styles.carouselRegion} sitaram-carousel-region`}
      aria-roledescription={staticMode ? undefined : 'carousel'}
      aria-label="Featured sacred services"
      tabIndex={staticMode ? undefined : 0}
      onKeyDown={staticMode ? undefined : onKeyDown}
    >
      {/* ROTATING SITARAM HERO PACKAGE */}
      <div
        key={slide.id}
        className={`${styles.rotatingHeroUnit} sitaram-rotating-unit ${ritual ? `${styles.ritualCarousel} sitaram-ritual-services` : ''} ${heroOne ? `${styles.heroOneCarousel} sitaram-hero-one` : ''} ${travel ? `${styles.travelCarousel} sitaram-travel-assistance` : ''}`}
      >
        <div
          className={`${styles.masterGrid} ${styles.upperHeroGrid} sitaram-upper-hero-grid`}
          role="group"
          aria-roledescription="slide"
          aria-label={`${activeHeroIndex + 1} of ${total}`}
        >
          {!staticMode ? <HeroArrows total={total} onPrevious={() => move(-1)} onNext={() => move(1)} /> : null}
          <div className={styles.heroMainColumn}>
            <div className={styles.heroCardWithFooter}>
              <HeroSlide slide={slide} />
              {/* HERO FOOTER — SITARAM HERO MASTER v1.1 */}
              {ritual ? (
                <footer className={`${styles.heroTrustFooter} ${styles.ritualHeroFooter}`}>
                  Ancient Tradition with Modern Peace of Mind
                </footer>
              ) : travel ? null : (
                <footer className={styles.heroTrustFooter} aria-label="Service trust standards">
                  <strong><span aria-hidden="true">◆</span>Confidentiality-First Support</strong>
                  <i aria-hidden="true">|</i>
                  <strong><span aria-hidden="true">●</span>Complete Privacy</strong>
                  <i aria-hidden="true">|</i>
                  <strong><span aria-hidden="true">✓</span>Expert Review &amp; Verification</strong>
                </footer>
              )}
            </div>
          </div>
          <HeroAssistantPanel slide={slide} />
        </div>
        <Link
          className={`${styles.exploreBar} sitaram-explore-bar ${ritual ? styles.ritualExploreBar : ''}`}
          href={slide.primaryHref}
          aria-label={heroOne ? 'Explore PitruMoksha Gaya' : undefined}
        >
          <span className={styles.exploreIcon} aria-hidden="true">
            {ritual ? '♨' : '♜'}
          </span>
          <span>
            <strong>{slide.exploreTitle}</strong>
            <small>{slide.exploreCopy}</small>
          </span>
          <b aria-hidden="true">›</b>
        </Link>
        {!staticMode ? <HeroDots current={activeHeroIndex} total={total} /> : null}
        <div className={`${styles.heroCoreServices} sitaram-core-services`}>
          <CoreServicesBand slide={slide} />
        </div>
      </div>
    </section>
  );
}
