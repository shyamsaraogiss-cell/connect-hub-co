import Image from 'next/image';
import Link from 'next/link';
import { coreServices } from '../data/heroSlides';
import { PITRU_MOKSHA_GAYA_ROUTE } from '../data/heroRoutes';
import type { HeroSlideData } from '../types/hero.types';
import styles from '../HeroCarousel.module.css';
import { TravelServiceIcon } from './TravelServiceIcon';
import { HERO_ONE_CORE_SERVICES } from '@/config/khem-navigation.config';

export const heroOneServices = HERO_ONE_CORE_SERVICES;
const heroIcons = heroOneServices.map((service) => service.icon);
export function CoreServicesBand({ slide }: { slide: HeroSlideData }) {
  const heroOne = slide.id === 'pitru-moksha-gaya';
  const travel = slide.id === 'travel-assistance';
  const slideServices = slide.featureItems?.length
    ? slide.featureItems.map((label, index) => ({
        label,
        icon: heroIcons[index % heroIcons.length],
        href: slide.primaryHref,
      }))
    : slide.servicePoints.length
      ? slide.servicePoints.map((service, index) => ({
          label: service.label,
          icon: heroIcons[index % heroIcons.length],
          href: slide.primaryHref,
        }))
      : coreServices;
  const services = heroOne
    ? heroOneServices.map((service) => ({ ...service, href: PITRU_MOKSHA_GAYA_ROUTE }))
    : slideServices;
  return (
    <section className={`${styles.coreServices} sitaram-core-services`} aria-labelledby="core-services-title">
      <h2 id="core-services-title">
        {heroOne ? (
          <>
            <Image
              className={styles.coreLotus}
              src="/images/brand/golden-lotus-mark.svg"
              alt=""
              width={46}
              height={36}
            />
            CORE SERVICES
          </>
        ) : travel ? (
          'Our Core Services'
        ) : (
          `${slide.title} Core Services`
        )}
      </h2>
      <div className={`${styles.serviceGrid} ${heroOne ? styles.heroOneServiceGrid : ''} ${travel ? styles.travelServiceGrid : ''}`}>
        {services.map((service) => (
          <Link href={service.href} key={service.label}>
            <span aria-hidden="true">{travel ? <TravelServiceIcon service={service.label} /> : service.icon}</span>
            <strong>{service.label}</strong>
          </Link>
        ))}
      </div>
    </section>
  );
}
