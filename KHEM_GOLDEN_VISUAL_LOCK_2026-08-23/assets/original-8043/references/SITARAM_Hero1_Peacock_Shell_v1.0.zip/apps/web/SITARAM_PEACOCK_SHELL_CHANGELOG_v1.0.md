# SITARAM Peacock Shell v1.0

Approved shell colour update applied.

Changed only:
- Global shell colour tokens
- Public header background
- Public shell background
- Public sidebar background
- Public footer background
- Core services/trust-style strip background

Approved palette:
- Top: `#0B5F67`
- Primary: `#096C6C`
- Bottom: `#074E56`
- Trust strip: `#0A5B63`
- Hero navy preserved: `#031E32`, `#06263D`

No Hero 1 content, layout, routes, logos, copy, data, or component structure was changed.
