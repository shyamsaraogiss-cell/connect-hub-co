"use client";
import Link from "next/link";import { usePathname } from "next/navigation";import { useState } from "react";import styles from "../PublicHeroShell.module.css";
type SidebarLink={label:string;href:string;icon:string;testMode?:boolean;divider?:boolean};
const links:readonly SidebarLink[]=[
  {label:"Home",href:"/",icon:"⌂"},
  {label:"Our Services",href:"/services",icon:"✦"},
  {label:"PitruMoksha Gaya",href:"/pitru-moksha",icon:"♜"},
  {label:"Ritual Services",href:"/services",icon:"◉"},
  {label:"Travel Assistance",href:"/travel-assistance",icon:"▣"},
  {label:"Virtual Shraddh",href:"/contact?mode=test&topic=virtual-shraddh",icon:"▤",testMode:true},
  {label:"Vahi (Panji) Records",href:"/contact?mode=test&topic=vahi-records",icon:"▥",testMode:true},
  {label:"Religious Partner Registration",href:"/contact?mode=test&topic=religious-partner-registration",icon:"♙",testMode:true,divider:true},
  {label:"Knowledge Centre",href:"/about",icon:"□",divider:true},
  {label:"Inquiry on Mail",href:"/contact?channel=email",icon:"✉",divider:true},
  {label:"WhatsApp Message",href:"/contact?mode=test&channel=whatsapp",icon:"◌",testMode:true},
] as const;
export function PublicHeroSidebar(){const path=usePathname();const [open,setOpen]=useState(false);return <><button className={styles.mobileTrigger} type="button" aria-expanded={open} aria-controls="public-hero-sidebar" onClick={()=>setOpen(value=>!value)}><span aria-hidden="true">☰</span>{open?"Close Explore menu":"Explore menu"}</button>{open?<button className={styles.backdrop} type="button" aria-label="Close Explore menu" onClick={()=>setOpen(false)}/>:null}<nav id="public-hero-sidebar" className={`${styles.sidebar} ${open?styles.open:""}`} aria-label="Explore Connect Hub Co"><div className={styles.mobileHeading}><strong>Explore</strong><button type="button" onClick={()=>setOpen(false)} aria-label="Close Explore menu">×</button></div>{links.map((item,index)=>{const active=(path===item.href&&item.label!=="Ritual Services")||(item.href==="/pitru-moksha"&&path.startsWith("/pitru-moksha"));return <div className={item.divider?styles.dividedItem:undefined} key={`${item.label}-${index}`}><Link className={active?styles.activeLink:""} href={item.href} onClick={()=>setOpen(false)} title={item.testMode?"Test-mode, non-transactional destination":undefined}><span aria-hidden="true">{item.icon}</span><span className={styles.linkLabel}>{item.label}{item.testMode?<small>Test mode</small>:null}</span></Link></div>})}</nav></>}
