import { HeroCarousel } from "@/features/hero";import { PublicHeroShell } from "@/features/public-shell";
export function BusinessHome(){return <PublicHeroShell><HeroCarousel/></PublicHeroShell>}
