export type HeroServicePoint = { label: string };
export type HeroSlideData = { id:string;logoSrc:string;logoAlt:string;title:string;tagline:string;supportingCopy:readonly string[];servicePoints:readonly HeroServicePoint[];location:string;locationSubtitle:string;exploreTitle:string;exploreCopy:string;primaryHref:string };
export type AssistantPrompt = { id:string;label:string;response:string;nextQuestion?:string;requiresAdmin?:boolean };
export type CoreService = { label:string;href:string;icon:string;testMode?:boolean };
