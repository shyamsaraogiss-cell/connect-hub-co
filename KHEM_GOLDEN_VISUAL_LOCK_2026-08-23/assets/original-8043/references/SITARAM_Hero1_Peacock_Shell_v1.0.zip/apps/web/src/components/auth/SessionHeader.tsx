"use client";

import { usePathname } from "next/navigation";
import { useAuth } from "./AuthProvider";
import Link from "next/link";

export function SessionHeader() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const publicPath=pathname==="/"||pathname==="/route-index"||pathname==="/login"||pathname==="/pitru-moksha"||pathname.startsWith("/pitru-moksha/success")||pathname==="/travel-assistance"||pathname.startsWith("/travel-assistance/success")||pathname==="/services"||pathname.startsWith("/services/");
  if(publicPath)return <header className="flex flex-wrap items-center gap-4 border-b bg-white px-4 py-3 sm:px-8"><Link className="mr-auto font-bold text-orange-900" href="/">Connect Hub Co</Link><Link href="/services">Services</Link><Link href="/pitru-moksha">PitruMoksha Gaya</Link><Link href="/travel-assistance">Travel Assistance</Link><Link href="/route-index">Route Guide</Link>{user?<Link className="rounded bg-blue-700 px-3 py-1 text-white" href="/dashboard">Dashboard</Link>:<Link className="rounded bg-blue-700 px-3 py-1 text-white" href="/login">Staff Login</Link>}</header>;
  if(!user)return null;
  return <header className="flex flex-wrap items-center gap-4 border-b bg-white px-4 py-3 sm:px-8"><Link className="mr-auto font-bold" href="/dashboard">Connect Hub ERP</Link><Link href="/partners">Partners</Link><Link href="/customers">Customers</Link><Link href="/bookings">Bookings</Link><Link href="/pitru-moksha/requests">PitruMoksha</Link><Link href="/travel-assistance/requests">Travel</Link><Link href="/admin/services">Services</Link><span className="text-sm text-gray-600">{user.name} · {user.role}</span><button className="rounded border px-3 py-1 text-sm" onClick={() => void logout()}>Logout</button></header>;
}
