import type { ReactNode } from "react";import { PublicHeroSidebar } from "./PublicHeroSidebar";import styles from "../PublicHeroShell.module.css";
export function PublicHeroShell({children}:{children:ReactNode}){return <div className={styles.shell}><div className={styles.layout}><PublicHeroSidebar/><div className={styles.content}>{children}</div></div></div>}
