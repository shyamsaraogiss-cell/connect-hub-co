"use client";

import { useEffect, useState } from "react";
import { getPartners } from "@/services/partner.api";
import { ReligiousPartner } from "@/types/partner";

export function usePartners() {
  const [partners, setPartners] = useState<ReligiousPartner[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      setError(null);
      setPartners(await getPartners());
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Unable to load partners.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let cancelled = false;
    void getPartners().then(rows => { if (!cancelled) setPartners(rows); }).catch(loadError => { if (!cancelled) setError(loadError instanceof Error ? loadError.message : "Unable to load partners."); }).finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  return { partners, loading, error, refresh };
}
