import type { Metadata } from "next";
import { PitruMokshaExplore } from "@/features/pitru-moksha/components/PitruMokshaExplore";
import { PublicHeroShell } from "@/features/public-shell";

export const metadata: Metadata = { title: "Pitru Moksha & Pind Daan in Gaya | Connect Hub Co", description: "Plan a respectful Pind Daan and Pitru Moksha seva in Gaya with verified religious partners, NRI coordination, and travel support.", keywords: ["Pind Daan Gaya", "Pitru Moksha Gaya", "Gaya pilgrimage", "NRI Pind Daan"] };
export default function PitruMokshaPage(){return <PublicHeroShell><PitruMokshaExplore/></PublicHeroShell>}
