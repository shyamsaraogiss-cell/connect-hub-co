# SITARAM_HERO_2_RITUAL_SERVICES_v1.1_FINAL_LOCK

STATUS:
PERMANENTLY LOCKED

The localhost Hero 2 Ritual Services implementation approved on 2026-07-23 is the permanent production baseline.

Locked requirements:

- Artwork: `/images/hero/hero2-ritual-services.png`
- Selected Service Locations remain below the description in two semantic rows.
- All approved location names remain visible.
- Only Nepal is bold sacred gold.
- The right carousel arrow remains outside the GenZ Ritual AI panel and anchored to the combined upper-row wrapper.
- The left carousel arrow remains outside the Hero Card.
- Hero 1, Header, Sidebar, Footer, AI panel, Explore Bar, Core Services, colours, logos, spacing, dimensions, and carousel synchronization remain unchanged.

Validation:

- Lint: passed with zero errors.
- Type-check: passed.
- Production build: passed.
- Desktop, tablet, and mobile overflow review: passed.

Do not modify without explicit user approval.
