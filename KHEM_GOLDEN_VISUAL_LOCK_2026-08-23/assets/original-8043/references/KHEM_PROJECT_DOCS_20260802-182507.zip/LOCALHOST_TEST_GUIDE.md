# Connect Hub Co localhost test guide

Start the API at `http://localhost:4000` and web app at `http://localhost:3000` using the existing local binaries. Set `NEXT_PUBLIC_API_URL=http://localhost:4000` for the web app.

Public route index: `http://localhost:3000/route-index`

Guest flow: Home → Services → service detail → PitruMoksha submission → confirmation → Travel Assistance → confirmation.

ERP flow: Login → Dashboard → Partners, Customers, Bookings, PitruMoksha Requests, Travel Requests, and Services Management. Logout from the shared ERP header.

Public API reads and submissions are under `/public/*`. All ERP API routes require the HTTP-only authentication cookie.
