**A SACRED GAYA JOURNEY, THOUGHTFULLY COORDINATED**

**PitruMoksha Gaya**

**Daan. Dharma. Moksha.**

Honour your ancestors in Gaya Ji—with clear guidance, verified coordination and compassionate support for families in India and across the world.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Your prayers remain at the centre.</strong></p>
<p>Whether you travel to Gaya Ji, join remotely or request authorised proxy assistance, we help you understand the process, prepare the required details and proceed through a clearly confirmed service plan.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**Location Gaya Ji, Bihar, India — The Land of Moksha**

**Our mission** To make sacred rituals more accessible through physical and online participation while preserving tradition, authenticity, respect and confidentiality.

*“The journey of Moksha is a duty of love. Let us handle the logistics while you focus on the prayers.”*

<table>
<colgroup>
<col style="width: 50%" />
<col style="width: 50%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>ASK GENZ RITUAL AI</strong></p>
<p>Get immediate guidance, 24×7</p></th>
<th><p><strong>REQUEST GUIDANCE</strong></p>
<p>Speak with our authorised team</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**WHY OVERSEAS FAMILIES CHOOSE US**

# Clarity before commitment

Performing an ancestral rite from another country can feel emotionally important and practically difficult. Our role is to replace uncertainty with a respectful, organised and transparent path.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>One trusted point of coordination</strong></p>
<p>Receive guidance on ritual options, family details, dates, travel, accessibility and local support through one organised process.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>A confirmed scope before booking</strong></p>
<p>Your official quotation states the approved service, inclusions, charges, validity and applicable terms before you proceed.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Respectful participation from anywhere</strong></p>
<p>Choose physical participation, virtual participation or authorised proxy assistance, subject to ritual suitability and expert confirmation.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Privacy without judgement</strong></p>
<p>Only the information needed for authorised processing should be collected. Sensitive family circumstances are handled confidentially.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# Choose the support that fits your family

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 33%" />
<col style="width: 33%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Visit Gaya Ji</strong></p>
<p>Participate physically with confirmed local coordination.</p></th>
<th><p><strong>Join Remotely</strong></p>
<p>Participate online when live access is practical, permitted and confirmed.</p></th>
<th><p><strong>Authorise a Proxy</strong></p>
<p>Request an authorised representative when a family member cannot travel, subject to expert review.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**UNDERSTAND THE SACRED JOURNEY**

# The Gaya ritual sequence

A Gaya ritual journey commonly includes sacred locations associated with Sankalpa, Tarpan, Pinda offerings, prayers and final immersion. The exact sequence, duration, offerings and access are confirmed for the selected ritual, family tradition, date and local rules.

| **Stage**              | **What may take place**                                                                         | **Purpose within the journey**                                                              |
|------------------------|-------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------|
| **1 Falgu River**      | Sacred preparation, Sankalpa, Tarpan and initial Pinda offerings.                               | The family formally states the intention and ancestor details under authorised guidance.    |
| **2 Vishnupad Temple** | Ritual offerings and prayers near the sacred footprint of Lord Vishnu, subject to temple rules. | The offerings are dedicated to the named ancestors.                                         |
| **3 Akshay Vat**       | Further Pinda offerings and concluding prayers beneath the sacred banyan tree.                  | A traditional concluding stage of the Gaya journey.                                         |
| **4 Final Visarjan**   | Ritual immersion of the Pindas, when included and instructed.                                   | The physical offerings are respectfully returned according to the confirmed ritual process. |

# Information to prepare

The authorised team may ask for the following details so that the ritual and quotation can be reviewed correctly:

- Name and contact details of the person requesting the service

- Name of the person who will lead or participate in the ritual

- Gotra, when known

- Names of the ancestors for whom the rites are requested, commonly up to three generations where relevant

- Preferred date or Tithi, if known

- Physical, virtual or proxy participation preference

- Travel, language, elderly-care or accessibility requirements

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Please do not worry if some details are unknown.</strong></p>
<p>Share what you know. Family-specific ritual questions, eligibility, date, route and required details will be reviewed before confirmation.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**SELECT A RITUAL GUIDANCE PATHWAY**

# Ritual service options

The following names help families identify the type of guidance they may need. The authorised expert confirms the appropriate ritual after reviewing the family’s circumstances.

| **Service**                        | **Indicative duration** | **When families commonly ask about it**                                                                                |
|------------------------------------|-------------------------|------------------------------------------------------------------------------------------------------------------------|
| **Standard Pind Daan**             | Around 3 hours          | A core ancestral offering in Gaya Ji.                                                                                  |
| **Pind Daan / Pitra Aatma Shanti** | Around 3–4 hours        | Guidance for ancestral peace and family remembrance.                                                                   |
| **Tripindi Shraddh**               | Around 4–6 hours        | Often requested where rites were missed or Pitra Dosha guidance is sought.                                             |
| **Complete Gaya Shraddh**          | Around 5–6 hours        | A more comprehensive Gaya ritual plan, subject to expert confirmation.                                                 |
| **Narayan Bali**                   | Around 3–6 hours        | A specialised request associated with particular circumstances, including unnatural death; expert review is essential. |
| **Shared Sankalp**                 | Confirmed case by case  | May be considered for eligible members of the same Gotra family, up to four families, subject to approval.             |

*Durations are indicative only. The final ritual, duration, offerings, locations, route, priest assignment and participation method are confirmed in the approved service scope.*

# Who may request or participate?

A family member or authorised representative may request guidance. Depending on the ritual, family tradition and individual circumstances, participation may be considered for sons, grandsons, brothers, spouses, unmarried women or an authorised proxy. The final guidance must come from the authorised ritual expert.

# When may the ritual be performed?

Rituals may be available throughout the year. Families often ask about Amavasya, Purnima, the departed person’s Tithi and Pitru Paksha. Date suitability, availability and any peak-period arrangements must be confirmed before travel or payment.

**CREATED FOR FAMILIES ACROSS THE WORLD**

# NRI and overseas-family support

Distance should not prevent a family from seeking respectful guidance. Tell us where you live, how you wish to participate and what practical help you need. We will prepare a suitable scope for review.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Silver — Remote Participation</strong></p>
<p>Virtual participation may include live video where practical and permitted, real-time Sankalp participation, proxy-led coordination when approved, and agreed completion evidence.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Gold — Guided Visit</strong></p>
<p>May include airport or local pickup, accommodation coordination, a dedicated local escort and ritual preparations. Every item is subject to availability and the official quotation.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Platinum — Bespoke Retreat</strong></p>
<p>May include a multi-day spiritual itinerary, private priest coordination, curated Sattvic meals, local cultural experiences and post-ritual documentation. The final plan is individually reviewed.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# Practical care in Gaya Ji

Depending on the confirmed plan, support may include:

- Hindi, English or bilingual coordination

- Reporting time, meeting point and route guidance

- Pre-arranged ritual materials (Samagri) and agreed Dakshina

- Help for women travelling alone, children and elderly guests

- Wheelchair or seating assistance, where available

- Pickup, accommodation or itinerary assistance when included

- Virtual participation instructions and technical coordination

- Approved completion proof or certificate when included in the confirmed plan

- Vahi Record guidance, subject to available family details and authorised custodians

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Transparent service scope</strong></p>
<p>Only the items written in the approved quotation are included. No unconfirmed donation, tip or additional cash payment should be treated as compulsory.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**A SIMPLE PATH FROM QUESTION TO CONFIRMATION**

# How it works

**01 Share your requirement**

> Ask GenZ Ritual AI, send an email or contact us on WhatsApp.

**02 Answer a few simple questions**

> With your consent, we may collect your name, country, contact details, ancestor information, Gotra, preferred date and participation preference.

**03 Receive human review**

> An authorised team member or ritual expert reviews sensitive, customised, availability and service questions.

**04 Receive the official quotation**

> The quotation states the approved service scope, inclusions, charges, validity and applicable terms.

**05 Confirm the booking**

> Booking is confirmed only after the required review and approved payment process are completed.

**06 Participate with coordinated support**

> The confirmed religious partner and support team coordinate the approved ritual and assistance.

# Trust, privacy and verification

- Religious partners are reviewed before recommendation or assignment.

- Family and ancestor information should be collected only for authorised processing.

- Sensitive family circumstances are handled confidentially and without judgement.

- The official quotation shows the approved scope and charges before booking.

- Booking, payment, change, cancellation and refund decisions require authorised human approval.

- Completion proof or a certificate is provided only when included in the confirmed plan.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>The role of GenZ Ritual AI</strong></p>
<p>The AI may educate, answer approved FAQs, collect consented enquiry details, suggest relevant service categories and escalate when needed. It does not independently issue quotations, collect payments, confirm or cancel bookings, approve refunds, or make final ritual decisions. Collected enquiry details are passed to the authorised team for review.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

*Connect Hub Co. coordinates the approved service process. Religious guidance remains subject to authorised experts, local rules and family circumstances. No religious or spiritual outcome is guaranteed.*

**ANSWERS BEFORE YOU DECIDE**

# Frequently asked questions

**Can I arrange the ritual from another country?**

Yes. You may request remote participation or authorised proxy assistance, subject to ritual suitability, local conditions and confirmation.

**Can a family member join online?**

Where live participation is practical and permitted, the confirmed plan may include a live connection and real-time Sankalp participation.

**Who can perform the ritual?**

Eligibility depends on the ritual, family tradition and individual circumstances. Share your situation for authorised guidance.

**What details should I keep ready?**

Your contact details, participant name, Gotra if known, ancestor names, preferred date and participation preference are helpful.

**Do you arrange travel and accommodation?**

Travel, pickup, accommodation and accessibility support may be arranged when included in the approved quotation.

**Are Samagri and Dakshina included?**

They may be included in the confirmed package. Please rely only on the written quotation for final inclusions.

**How much does the service cost?**

Charges depend on the ritual, participation method, date, support and selected plan. The authorised team provides the official quotation.

**Will I receive proof of completion?**

Approved completion proof or a certificate may be provided when included in the confirmed plan.

**Can you help with Vahi Records?**

Yes, you may request guidance. Search and verification depend on the available family details and authorised record custodians.

**How is my family information handled?**

Only necessary information should be collected for authorised processing and handled confidentially.

**BEGIN WITH ONE SIMPLE CONVERSATION**

# Your family’s requirement is personal. Your guidance should be too.

Tell us what you wish to arrange, where you are located and how your family would like to participate. We will help you understand the next step and prepare the request for authorised review.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Not sure which ritual to choose?</strong></p>
<p>Start with your family situation—not a package name. GenZ Ritual AI can provide approved introductory guidance and pass your enquiry to the authorised team when human confirmation is required.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# Choose your next step

**01 Ask GenZ Ritual AI**

> Receive approved FAQ guidance at any time.

**02 Request Personal Guidance**

> Share your family requirement for authorised review.

**03 Request an Official Quotation**

> Receive the approved scope, inclusions and charges before booking.

**04 Contact Support**

> Ask about travel, accessibility, language or existing enquiries.

**The Authentic Ancestral Rites \| Verified Lineage \| Vedic Precision**

**PitruMoksha Gaya • Gaya Ji, Bihar, India**

*“The journey of Moksha is a duty of love. Let us handle the logistics while you focus on the prayers.”*

| **REQUEST GUIDANCE • ASK GENZ RITUAL AI** |
|-------------------------------------------|
