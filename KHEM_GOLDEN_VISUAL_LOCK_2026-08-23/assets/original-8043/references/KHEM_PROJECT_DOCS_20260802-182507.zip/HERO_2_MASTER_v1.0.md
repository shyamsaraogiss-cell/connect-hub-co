# SITARAM LOCK — HERO_2_MASTER_v1.0

STATUS: PERMANENTLY LOCKED

Approved and frozen on 2026-07-23 as the Ritual Services Hero 2 master.

No redesign, replacement, structural change, or visual reinterpretation is permitted unless explicitly unlocked by Shyam.

## Locked shell and structure

- Header
- Sidebar
- Hero card layout
- GenZ Ritual AI panel shell
- Explore Bar
- Footer
- Peacock Blue and Sacred Gold theme
- Typography hierarchy
- Hero spacing
- Carousel structure and synchronization
- Left navigation arrow outside the Hero Card
- Right navigation arrow outside the GenZ Ritual AI panel
- Integrated punch line: “Ancient Tradition with Modern Peace of Mind”

## Locked Hero 2 content

Title:

> Ritual Services

Description:

> Every ritual carries its own purpose, tradition, and prescribed method.

Approved Core Services, in order:

1. Griha Pravesh
2. Marriage Rituals
3. Customized Puja
4. Upanayan Sanskar
5. Havan & Homam
6. Preferred Location Puja
7. Navagraha Shanti
8. Dosha Remedies
9. Festival Rituals
10. Others / Rituals

Selected Service Locations remain enlarged near the bottom of the Hero Card, with Nepal highlighted.

## Locked visual standard

- Production artwork: `/images/hero/hero2-ritual-services.png`
- Artwork-only image with no webpage UI
- Premium bronze and copper finish
- Bright, detailed sacred fire
- Polished reflections
- Detailed outer deity medallions
- Distinct inner sacred ring
- Warm sacred-gold illumination
- No blue haze

## Version baseline

SHA-256:

- `apps/web/public/images/hero/hero2-ritual-services.png` — `36E75786F37531022942B7BBF729BFFB8DC4B0AB78554315BB8FCA7F5C597A69`
- `apps/web/src/features/hero/HeroCarousel.module.css` — `DE8B4F6CADF13E341FA00977E90AE1F7820E7E272B5D8995211DD2FC4FC198AA`
- `apps/web/src/features/hero/components/HeroCarousel.tsx` — `53392D898670859A3C52E2E1EBBED42148F77D3AAEE91FFC36FF1EDF07DE8E80`
- `apps/web/src/features/hero/components/HeroSlide.tsx` — `9DDF703322E09CB2957244769306F0C807214510FA05BA73F4421A6F8C4A6D46`
- `apps/web/src/features/hero/data/homepageHeroSlides.ts` — `5178522935D4689939E9C7B594991A8EFBF195CA262079C1FBC6869C81DB9156`

Any intentional modification requires explicit unlock approval from Shyam and a new versioned lock manifest.
