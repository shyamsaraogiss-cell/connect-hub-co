import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/components/auth/AuthProvider";
import { PublicHeader } from "@/components/auth/PublicHeader";
import { BusinessFooter } from "@/components/auth/BusinessFooter";
import { PageContent } from "@/components/common/PageContent";

// =======================================
// SITARAM HERO MASTER v1.1
// PERMANENTLY LOCKED
// DO NOT MODIFY WITHOUT EXPLICIT APPROVAL
// FIXED SHELL
// =======================================
const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: { default: "Connect Hub Co | Sacred Services & Travel Support", template: "%s | Connect Hub Co" },
  description: "Trusted Pitru Moksha services in Gaya, religious service coordination, and complete pilgrim travel assistance.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <AuthProvider>
          {/* FIXED SITARAM SHELL — DO NOT MODIFY */}
          <PublicHeader />
          <PageContent>{children}</PageContent>
          <BusinessFooter />
        </AuthProvider>
      </body>
    </html>
  );
}
