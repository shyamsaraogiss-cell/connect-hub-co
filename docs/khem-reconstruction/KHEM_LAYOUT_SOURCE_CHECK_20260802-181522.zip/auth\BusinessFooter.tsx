'use client';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ROUTES } from '@/config/navigation';

import { KHEM_FOOTER_NAVIGATION } from '@/config/khem-navigation.config';

export function BusinessFooter() {
  const path = usePathname();
  const show =
    [
      ROUTES.HOME,
      '/about',
      ROUTES.INQUIRY,
      ROUTES.LOGIN,
      '/pitru-moksha',
      ROUTES.PITRU_MOKSHA_GAYA,
      ROUTES.RITUAL_SERVICES,
      ROUTES.RELIGIOUS_PARTNERS,
      ROUTES.TRAVEL_ASSISTANCE,
      ROUTES.VAHI_RECORDS,
      ROUTES.BOOKING,
      ROUTES.ASK_GENZ_AI,
      ROUTES.KNOWLEDGE_CENTER,
      ROUTES.TRACKING,
      ROUTES.COMPLAINT,
      ROUTES.GRIEVANCE,
      ROUTES.FOUNDER_SUPPORT,
      ROUTES.PRIVACY_POLICY,
      ROUTES.TERMS,
      ROUTES.BOOKING_TERMS,
      ROUTES.CANCELLATION_POLICY,
    ].includes(path) ||
    path.startsWith(ROUTES.PITRU_MOKSHA_GAYA) ||
    path.startsWith(ROUTES.RITUAL_SERVICES) ||
    path.startsWith('/services/') ||
    path.endsWith('/success');

  if (!show) return null;

  return (
    <footer className="peacock-shell-background relative z-10 w-full border-t border-[var(--border-soft)] pt-9 text-[var(--text-on-peacock)]">
      <div className="mx-auto grid max-w-[1500px] gap-8 px-5 sm:grid-cols-2 lg:grid-cols-5">
        {/* Brand Header Column */}
        <div>
          <Link href="/" className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <Image src="/images/brand/golden-lotus-mark.svg" alt="Connect Hub Co. Logo" width={62} height={48} />
            <h2 className="font-serif text-2xl font-bold">Connect Hub Co.</h2>
          </Link>
          <p className="mt-3 text-sm leading-6 text-[var(--ritual-gold)]">
            We combine tradition with technology to make your spiritual journey smooth, transparent, and meaningful.
          </p>
          <nav className="mt-4 flex flex-wrap gap-2" aria-label="Social links">
            {[
              ['Facebook', 'f'],
              ['Instagram', '◎'],
              ['YouTube', '▶'],
              ['LinkedIn', 'in'],
            ].map(([label, icon]) => (
              <Link
                className="grid h-9 min-w-9 place-items-center rounded-full border border-[var(--ritual-gold)] px-2 text-sm font-bold text-[var(--ritual-gold)]"
                href={`/contact?topic=social-${label.toLowerCase()}`}
                aria-label={label}
                key={label}
              >
                {icon}
              </Link>
            ))}
          </nav>
        </div>

        {/* 4 Approved Columns dynamically mapped from KHEM_FOOTER_NAVIGATION */}
        {KHEM_FOOTER_NAVIGATION.map((column, colIdx) => (
          <div key={column.title}>
            <h3 className="font-semibold text-[var(--ritual-gold)]">{column.title}</h3>
            <div className="mt-3 grid gap-2 text-sm">
              {column.links.map(([label, href], idx) => (
                <Link href={href} key={`${label}-${idx}`}>
                  {label}
                </Link>
              ))}
            </div>
            {/* Homepage-Only Request Updates Card at Bottom-Right Corner of Footer */}
            {path === '/' && colIdx === KHEM_FOOTER_NAVIGATION.length - 1 ? (
              <div className="mt-6 rounded-xl border border-[var(--border-soft)] bg-white/10 p-4 backdrop-blur-sm space-y-2.5">
                <div className="flex items-center gap-2">
                  <Image src="/images/brand/golden-lotus-mark.svg" alt="Request Updates Mark" width={28} height={22} />
                  <h4 className="font-serif font-bold text-sm text-[var(--ritual-gold)]">Request Updates</h4>
                </div>
                <p className="text-xs text-white/90 leading-relaxed">
                  Receive verified updates on auspicious tithis, ritual schedules, and spiritual guides.
                </p>
                <form
                  action="/contact"
                  method="GET"
                  className="flex flex-col gap-2 pt-1"
                  aria-label="Request updates subscription form"
                >
                  <input type="hidden" name="topic" value="stay-updated" />
                  <input
                    type="email"
                    required
                    placeholder="Enter email or phone…"
                    className="w-full rounded-lg border border-white/30 bg-white/20 px-3 py-1.5 text-xs text-white placeholder-white/70 outline-none focus:border-[var(--ritual-gold)] focus:ring-1 focus:ring-[var(--ritual-gold)]"
                  />
                  <button
                    type="submit"
                    className="w-full rounded-lg bg-[var(--ritual-gold,#F4B942)] py-1.5 text-xs font-bold text-[#083F4A] hover:opacity-95 transition-opacity"
                  >
                    Subscribe →
                  </button>
                </form>
              </div>
            ) : null}
          </div>
        ))}
      </div>
      <p className="mx-auto mt-8 max-w-[1500px] px-5 text-center text-xs text-white/75">
        Images shown are representative illustrations. Actual rituals, locations, and arrangements may vary.
      </p>
      <div className="global-footer-bottom mt-4 w-full border-t border-[var(--border-soft)] px-5 py-5 text-center text-sm">
        © {new Date().getFullYear()} Connect Hub Co. All rights reserved.
      </div>
    </footer>
  );
}
