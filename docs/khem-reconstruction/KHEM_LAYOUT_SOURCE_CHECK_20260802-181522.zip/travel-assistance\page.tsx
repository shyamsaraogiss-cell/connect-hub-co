import type { Metadata } from 'next';
import { StaticBusinessHeroPage } from '@/components/business-pages/StaticBusinessHeroPage';
import { TravelAssistanceContent } from '@/components/business-pages/travel-assistance/TravelAssistanceContent';

export const metadata: Metadata = {
  title: 'Travel Assistance & Pilgrim Journey Coordination | Connect Hub Co.',
  description:
    '24×7 Complete Journey Management and Travel Assistance across India & Nepal. Airport pickup, hotel accommodation, local ground transport, and Shadow Assist.',
};

export default function TravelAssistancePage() {
  return (
    <StaticBusinessHeroPage slideId="travel-assistance">
      <div id="travel-details">
        <TravelAssistanceContent />
      </div>
    </StaticBusinessHeroPage>
  );
}

