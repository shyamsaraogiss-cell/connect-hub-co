'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import {
  getCurrentUser,
  getStoredSession,
  login as loginRequest,
  logout as logoutRequest,
  register as registerRequest,
  forgotPassword as forgotPasswordRequest,
  resetPassword as resetPasswordRequest,
  verifyEmail as verifyEmailRequest,
} from '@/services/auth.api';
import type {
  AuthResponse,
  AuthUser,
  ForgotPasswordInput,
  LoginInput,
  RegisterInput,
  ResetPasswordInput,
  UserRole,
  VerifyEmailInput,
} from '@/types/auth';

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  login: (input: LoginInput) => Promise<AuthResponse>;
  register: (input: RegisterInput) => Promise<AuthResponse>;
  forgotPassword: (input: ForgotPasswordInput) => Promise<{ message: string }>;
  resetPassword: (input: ResetPasswordInput) => Promise<{ message: string }>;
  verifyEmail: (input: VerifyEmailInput) => Promise<{ message: string }>;
  logout: () => Promise<void>;
  hasRole: (roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const publicPaths = new Set([
  '/',
  '/about',
  '/contact',
  '/login',
  '/register',
  '/forgot-password',
  '/reset-password',
  '/verify-email',
  '/pitru-moksha',
  '/pitru-moksha-gaya',
  '/pitru-moksha-gaya/online',
  '/pitru-moksha-gaya/offline',
  '/religious-partners',
  '/ritual-services',
  '/route-index',
  '/services',
  '/travel-assistance',
  '/vahi-records',
  '/zen-g',
]);

const roleRedirects: Record<UserRole, string> = {
  ADMIN: '/admin',
  STAFF: '/dashboard',
  PARTNER: '/dashboard',
  CUSTOMER: '/dashboard',
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<AuthUser | null>(() => getStoredSession()?.user || null);
  const [loading, setLoading] = useState<boolean>(() => !getStoredSession()?.user);

  const isPublic =
    publicPaths.has(pathname) ||
    pathname.startsWith('/pitru-moksha/success') ||
    pathname.startsWith('/travel-assistance/success') ||
    pathname.startsWith('/services/');

  useEffect(() => {
    if (user) return;
    let active = true;
    void getCurrentUser()
      .then(({ user: currentUser }) => {
        if (active) setUser(currentUser);
      })
      .catch(() => {
        if (active) setUser(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [user]);

  useEffect(() => {
    if (!loading && !user && !isPublic) {
      router.replace('/login');
    }
    if (!loading && user && (pathname === '/login' || pathname === '/register')) {
      const redirectPath = roleRedirects[user.role] || '/dashboard';
      router.replace(redirectPath);
    }
  }, [isPublic, loading, pathname, router, user]);

  const login = useCallback(
    async (input: LoginInput) => {
      const response = await loginRequest(input);
      setUser(response.user);
      const redirectPath = roleRedirects[response.user.role] || '/dashboard';
      router.replace(redirectPath);
      return response;
    },
    [router]
  );

  const register = useCallback(
    async (input: RegisterInput) => {
      const response = await registerRequest(input);
      setUser(response.user);
      const redirectPath = roleRedirects[response.user.role] || '/dashboard';
      router.replace(redirectPath);
      return response;
    },
    [router]
  );

  const forgotPassword = useCallback(async (input: ForgotPasswordInput) => {
    return forgotPasswordRequest(input);
  }, []);

  const resetPassword = useCallback(async (input: ResetPasswordInput) => {
    return resetPasswordRequest(input);
  }, []);

  const verifyEmail = useCallback(async (input: VerifyEmailInput) => {
    return verifyEmailRequest(input);
  }, []);

  const logout = useCallback(async () => {
    try {
      await logoutRequest();
    } finally {
      setUser(null);
      router.replace('/login');
    }
  }, [router]);

  const hasRole = useCallback(
    (roles: UserRole[]) => {
      if (!user) return false;
      return roles.includes(user.role);
    },
    [user]
  );

  const value = useMemo(
    () => ({
      user,
      loading,
      login,
      register,
      forgotPassword,
      resetPassword,
      verifyEmail,
      logout,
      hasRole,
    }),
    [user, loading, login, register, forgotPassword, resetPassword, verifyEmail, logout, hasRole]
  );

  const canRender = isPublic || (!loading && user);

  return (
    <AuthContext.Provider value={value}>
      {canRender ? (
        children
      ) : (
        <main className="grid min-h-screen place-items-center bg-stone-50 p-6 text-stone-700">
          <div className="text-center">
            <div className="mx-auto h-8 w-8 animate-spin rounded-full border-4 border-teal-600 border-t-transparent"></div>
            <p className="mt-4 font-semibold text-teal-800">Verifying authentication session…</p>
          </div>
        </main>
      )}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider.');
  return value;
}
