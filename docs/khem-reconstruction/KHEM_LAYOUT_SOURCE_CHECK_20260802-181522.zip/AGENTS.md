# Connect Hub Co. - SITARAM Project Rules

## Project

Connect Hub Co.
Religious Service and Travel Assistance Company.

## Technology

- Next.js App Router
- React
- TypeScript
- Tailwind CSS 4
- Turborepo
- pnpm

## Before Every Task

- Read the existing project architecture before making changes.
- Reuse existing shared components whenever possible.
- Preserve approved layouts and branding.
- Never redesign approved UI unless explicitly instructed.
- Keep production-quality code.

## Locked Components

Do not modify without approval:

- Header
- Sidebar
- Footer
- Hero framework
- AI Panel shell
- Approved Hero Masters
- Peacock Blue and Sacred Gold design system

## Code Standards

- TypeScript only
- Responsive design
- Accessibility
- Semantic HTML
- Reusable components
- Clean code

## Never

- Delete files
- Reset Git
- Commit
- Push
- Install unnecessary packages
- Modify unrelated files

## Validation

After every implementation:

- Run lint
- Run type-check

Report only:

- Files modified
- Files created
- Validation results
- Blocking issues