"use client";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useAuth } from "./AuthProvider";
import { WhatsAppIcon } from "@/components/common/WhatsAppIcon";
import { ROUTES } from "@/config/navigation";

const links = [
  ["Knowledge Center", ROUTES.KNOWLEDGE_CENTER],
  ["Services", ROUTES.BOOKING],
  ["Pitru Moksha", ROUTES.PITRU_MOKSHA_GAYA],
  ["Travel", ROUTES.TRAVEL_ASSISTANCE],
  ["GenZ AI", ROUTES.ASK_GENZ_AI],
  ["Contact", ROUTES.INQUIRY],
] as const;

export function PublicHeader() {
  const path = usePathname();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const show =
    [
      ROUTES.HOME,
      "/about",
      ROUTES.KNOWLEDGE_CENTER,
      ROUTES.INQUIRY,
      ROUTES.LOGIN,
      "/pitru-moksha",
      ROUTES.PITRU_MOKSHA_GAYA,
      ROUTES.RITUAL_SERVICES,
      ROUTES.VAHI_RECORDS,
      ROUTES.TRAVEL_ASSISTANCE,
      ROUTES.RELIGIOUS_PARTNERS,
      ROUTES.BOOKING,
      ROUTES.ASK_GENZ_AI,
      ROUTES.TRACKING,
      ROUTES.COMPLAINT,
      ROUTES.GRIEVANCE,
      ROUTES.FOUNDER_SUPPORT,
      ROUTES.PRIVACY_POLICY,
      ROUTES.TERMS,
      ROUTES.BOOKING_TERMS,
      ROUTES.CANCELLATION_POLICY,
    ].includes(path) ||
    path.startsWith(ROUTES.PITRU_MOKSHA_GAYA) ||
    path.startsWith(ROUTES.RITUAL_SERVICES) ||
    path.startsWith("/services/") ||
    path.endsWith("/success");

  if (!show) return null;

  return (
    <header className="peacock-shell-background sticky top-0 z-50 min-h-[96px] border-b border-[var(--border-soft)] text-[var(--text-on-peacock)] shadow-[0_4px_18px_rgba(8,127,140,0.28)]">
      <nav className="mx-auto max-w-[1536px] px-4 py-2" aria-label="Primary navigation">
        <div className="flex min-h-[78px] items-center gap-4">
          <div className="mr-auto flex items-center gap-3">
            <Link
              className="flex items-center gap-3 rounded-md px-1 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[var(--ritual-gold)]"
              href={ROUTES.HOME}
              onClick={() => setOpen(false)}
              aria-label="Go to Connect Hub Co. home"
            >
              <span className="grid h-14 w-14 place-items-center" aria-hidden="true">
                <Image src="/images/brand/golden-lotus-mark.svg" alt="" width={56} height={44} priority />
              </span>
              <strong className="block font-serif text-[30px] leading-tight xl:text-[34px]">Connect Hub Co.</strong>
            </Link>
            <span className="hidden sm:block">
              <small className="mt-1 block text-[14px] leading-snug text-[var(--gold-bright)] xl:text-[15px]">
                The Authentic Ancestral Rites | Verified Lineage | Vedic Precision
              </small>
            </span>
          </div>
          <Link
            className="hidden h-12 w-12 items-center justify-center rounded-full border border-[var(--ritual-gold)] text-[var(--ritual-gold)] lg:inline-flex"
            href={ROUTES.WHATSAPP}
            title="WhatsApp guidance"
            aria-label="WhatsApp message"
          >
            <WhatsAppIcon className="h-7 w-7" />
          </Link>
          <Link
            className="hidden rounded-xl border border-white/75 px-5 py-2.5 font-semibold text-white sm:inline-flex"
            href={user ? ROUTES.DASHBOARD : ROUTES.LOGIN}
          >
            {user ? "Dashboard" : "Login / Sign Up"}
          </Link>
          <Link
            className="hidden rounded-xl bg-[var(--ritual-gold)] px-5 py-2.5 font-semibold text-[#087F8C] md:inline-flex"
            href={ROUTES.BOOKING}
          >
            Book Now
          </Link>
          <button
            className="rounded-lg border border-white/70 px-3 py-2 sm:hidden"
            type="button"
            aria-expanded={open}
            aria-controls="public-mobile-menu"
            aria-label={open ? "Close navigation menu" : "Open navigation menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? "Close" : "Menu"}
          </button>
        </div>
        {open ? (
          <div
            id="public-mobile-menu"
            className="peacock-shell-background mt-2 grid gap-1 border-t border-[var(--border-soft)] pt-3 sm:hidden"
          >
            {links.map(([label, href]) => (
              <Link
                className="rounded-lg px-3 py-2 hover:bg-white/15 focus:bg-white/15"
                href={href}
                key={href}
                onClick={() => setOpen(false)}
              >
                {label}
              </Link>
            ))}
            <Link
              className="flex items-center gap-2 rounded-lg px-3 py-2 hover:bg-white/15"
              href={ROUTES.WHATSAPP}
              onClick={() => setOpen(false)}
            >
              <WhatsAppIcon className="h-5 w-5" />
              WhatsApp Message
            </Link>
            <Link
              className="rounded-lg px-3 py-2 hover:bg-white/15"
              href={user ? ROUTES.DASHBOARD : ROUTES.LOGIN}
              onClick={() => setOpen(false)}
            >
              {user ? "Dashboard" : "Login / Sign Up"}
            </Link>
            <Link
              className="mt-1 rounded-lg bg-[var(--ritual-gold)] px-3 py-2 font-semibold text-[#087F8C]"
              href={ROUTES.BOOKING}
              onClick={() => setOpen(false)}
            >
              Book Now
            </Link>
          </div>
        ) : null}
      </nav>
    </header>
  );
}
