import type { Metadata } from 'next';
import { BusinessHome } from '@/components/common/BusinessHome';

export const metadata: Metadata = {
  title: 'Connect Hub Co. | Religious Services & Sacred Travel Coordination',
  description: 'Discover ritual services, plan PitruMoksha in Gaya, and arrange sacred travel assistance with verified Religious Partners and GenZ Ritual AI guidance.',
};

export default function HomePage() {
  return <BusinessHome />;
}

